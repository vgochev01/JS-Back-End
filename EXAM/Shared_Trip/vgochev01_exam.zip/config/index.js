module.exports = {
    PORT: 3000,
    TOKEN_SECRET: 'my very secure secret',
    COOKIE_NAME: 'SESSION_DATA',
    CONNECTION_STR: 'mongodb://localhost:27017/trips'
}